#!/usr/bin/env node
import { readFileSync, writeFileSync } from "node:fs";
import { chromium } from "playwright";

const oswald = readFileSync("/workspace/.grok/fonts/Oswald.ttf").toString("base64");
const bodoni = readFileSync("/workspace/.grok/fonts/BodoniModa.ttf").toString("base64");
const portrait = readFileSync("/workspace/attachments/1000011067.jpg").toString("base64");

const html = `<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="utf-8" />
<style>
@font-face {
  font-family: "Oswald";
  src: url(data:font/ttf;base64,${oswald}) format("truetype");
  font-weight: 200 700;
  font-style: normal;
  font-display: block;
}
@font-face {
  font-family: "Bodoni Moda";
  src: url(data:font/ttf;base64,${bodoni}) format("truetype");
  font-weight: 100 900;
  font-style: normal;
  font-display: block;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
html, body {
  width: 1200px;
  height: 630px;
  overflow: hidden;
  background: #FAF6F1;
}
.card {
  position: relative;
  width: 1200px;
  height: 630px;
  background: #FAF6F1;
  color: #1C1010;
}
.spine {
  position: absolute;
  left: 0; top: 0; bottom: 0;
  width: 16px;
  background: #6B1C22;
}
.portrait {
  position: absolute;
  top: 0; right: 0; bottom: 0;
  width: 468px;
  overflow: hidden;
  background: #4A1218;
}
.portrait img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  object-position: 58% 10%;
  filter: contrast(1.12) saturate(0.72) brightness(0.94);
}
.portrait::after {
  content: "";
  position: absolute;
  inset: 0;
  background:
    linear-gradient(90deg, #FAF6F1 0%, rgba(250,246,241,0) 7%),
    linear-gradient(180deg, rgba(107,28,34,0.18) 0%, rgba(28,16,16,0.32) 100%);
  pointer-events: none;
}
.portrait::before {
  content: "";
  position: absolute;
  left: 0; top: 0; bottom: 0;
  width: 1px;
  background: rgba(107, 28, 34, 0.28);
  z-index: 2;
}
.copy {
  position: absolute;
  left: 88px;
  top: 0;
  bottom: 0;
  width: 680px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  z-index: 2;
}
.monogram {
  position: absolute;
  top: 42px;
  left: 88px;
  z-index: 3;
  font-family: "Bodoni Moda", serif;
  font-weight: 700;
  font-size: 20px;
  letter-spacing: 0.28em;
  color: #6B1C22;
}
.name {
  font-family: "Oswald", sans-serif;
  font-weight: 600;
  font-size: 118px;
  line-height: 0.86;
  letter-spacing: 0.01em;
  text-transform: uppercase;
  color: #1C1010;
}
.name .accent { color: #6B1C22; }
.rule {
  width: 64px;
  height: 2px;
  background: #6B1C22;
  margin: 30px 0 22px;
}
.tag {
  font-family: "Oswald", sans-serif;
  font-weight: 400;
  font-size: 16px;
  letter-spacing: 0.34em;
  text-transform: uppercase;
  color: #4A1218;
}
.grain {
  position: absolute;
  inset: 0;
  z-index: 6;
  pointer-events: none;
  opacity: 0.07;
  mix-blend-mode: multiply;
  background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='180' height='180'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/></filter><rect width='100%25' height='100%25' filter='url(%23n)'/></svg>");
}
</style>
</head>
<body>
  <div class="card">
    <div class="spine"></div>
    <div class="monogram">TD</div>
    <div class="copy">
      <div class="name">THÀNH<br><span class="accent">ĐẠT</span></div>
      <div class="rule"></div>
      <div class="tag">Web Developer · AI · Creative</div>
    </div>
    <div class="portrait">
      <img src="data:image/jpeg;base64,${portrait}" alt="" />
    </div>
    <div class="grain"></div>
  </div>
</body>
</html>
`;

writeFileSync("/workspace/.grok/og-card.html", html);

const browser = await chromium.launch({
  headless: true,
  args: ["--no-sandbox", "--disable-dev-shm-usage"],
});
try {
  const page = await browser.newPage({
    viewport: { width: 1200, height: 630 },
    deviceScaleFactor: 2,
  });
  await page.setContent(html, { waitUntil: "load" });
  await page.evaluate(() => document.fonts.ready);
  await page.waitForTimeout(200);
  await page.screenshot({
    path: "/workspace/.grok/og-raw.png",
    type: "png",
    clip: { x: 0, y: 0, width: 1200, height: 630 },
  });
  console.log("wrote /workspace/.grok/og-raw.png");
} finally {
  await browser.close();
}
