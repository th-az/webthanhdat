//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Hy-g_BA9.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/ASPIRE/Downloads/thanhdatflolio (1)/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/contact",
			"/skills",
			"/projects/$projectId",
			"/projects/"
		],
		preloads: ["/assets/index-DRRJKI-a.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DRRJKI-a.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/ASPIRE/Downloads/thanhdatflolio (1)/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-BCTqFYJe.js",
			"/assets/arrow-right-OPAMfrnU.js",
			"/assets/instagram-usT7-HmH.js",
			"/assets/layers-CbFsro9l.js",
			"/assets/site-layout-DBWUb-CG.js",
			"/assets/sparkles-DcCoA1ag.js",
			"/assets/project-dialog-CYVPpFs0.js"
		]
	},
	"/about": {
		filePath: "C:/Users/ASPIRE/Downloads/thanhdatflolio (1)/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about-DP0Y8UPz.js",
			"/assets/arrow-right-OPAMfrnU.js",
			"/assets/circle-check-DmCdVVck.js",
			"/assets/map-pin-DS4DfzmX.js",
			"/assets/site-layout-DBWUb-CG.js",
			"/assets/sparkles-DcCoA1ag.js",
			"/assets/page-header-DEQLSiVz.js"
		]
	},
	"/contact": {
		filePath: "C:/Users/ASPIRE/Downloads/thanhdatflolio (1)/src/routes/contact.tsx",
		children: void 0,
		preloads: [
			"/assets/contact-CfaHtkC1.js",
			"/assets/instagram-usT7-HmH.js",
			"/assets/map-pin-DS4DfzmX.js",
			"/assets/site-layout-DBWUb-CG.js",
			"/assets/sparkles-DcCoA1ag.js",
			"/assets/page-header-DEQLSiVz.js"
		]
	},
	"/skills": {
		filePath: "C:/Users/ASPIRE/Downloads/thanhdatflolio (1)/src/routes/skills.tsx",
		children: void 0,
		preloads: [
			"/assets/skills-BYaAM-Ro.js",
			"/assets/arrow-right-OPAMfrnU.js",
			"/assets/layers-CbFsro9l.js",
			"/assets/site-layout-DBWUb-CG.js",
			"/assets/page-header-DEQLSiVz.js"
		]
	},
	"/projects/$projectId": {
		filePath: "C:/Users/ASPIRE/Downloads/thanhdatflolio (1)/src/routes/projects/$projectId.tsx",
		children: void 0,
		preloads: [
			"/assets/_projectId-Cxa62j0L.js",
			"/assets/arrow-right-OPAMfrnU.js",
			"/assets/circle-check-DmCdVVck.js",
			"/assets/site-layout-DBWUb-CG.js",
			"/assets/sparkles-DcCoA1ag.js"
		]
	},
	"/projects/": {
		filePath: "C:/Users/ASPIRE/Downloads/thanhdatflolio (1)/src/routes/projects/index.tsx",
		children: void 0,
		preloads: [
			"/assets/projects-XRh_l4dk.js",
			"/assets/arrow-right-OPAMfrnU.js",
			"/assets/site-layout-DBWUb-CG.js",
			"/assets/sparkles-DcCoA1ag.js",
			"/assets/page-header-DEQLSiVz.js",
			"/assets/project-dialog-CYVPpFs0.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
